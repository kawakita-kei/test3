 $('#page').live('pagecreate',function(){
	$('#btn1').live('vclick',doAction);		
	});
	function doAction(){   
    	$("img").attr("src","img/rw.jpg");
	}

	function jump1() {
            
            if(document.form1.radio1[1].checked == true){
		var x = document.getElementById('radio1_1').value;
	    
		
		 $.mobile.changePage($("#page3"));
          }
	}
